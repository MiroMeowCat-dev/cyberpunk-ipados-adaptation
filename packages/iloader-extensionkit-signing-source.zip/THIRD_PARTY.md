# Signing source attribution

This is the unofficial local ExtensionKit sign-only adaptation of iLoader 2.4.1.
Upstream iLoader is MIT, commit 9797ecaf6ccdcfc68bd2ef4e0b1123910dd847b6.
Official project https://github.com/nab138/iloader and https://iloader.app .
Branding remains subject to iloader/LICENSE-BRANDING. This is an educational fork.

isideload 0.5.2 is MIT https://github.com/nab138/isideload .
apple-codesign-quick 0.1.0 is LGPL-2.1-or-later https://github.com/Dadoum/apple-crates .
The corresponding modified source is included. No signing executable is distributed.
See licenses in the main archive for full license texts.

Build iLoader from iloader/ with npm ci and its existing Tauri build command.
The source uses the two relative local Rust crates. Use your own Rust/Node build environment.
The apple-codesign-quick source expects two public Apple CA roots under assets/.
Run fetch-public-roots.py with Python to retrieve and hash-check these public roots.
These are public trust anchors, not a developer identity or signing certificate.
Passwords and OTPs belong in the signing tool only. The sign-only flow registers
real App IDs, devices and profiles with Apple. Save Credentials is optional.
