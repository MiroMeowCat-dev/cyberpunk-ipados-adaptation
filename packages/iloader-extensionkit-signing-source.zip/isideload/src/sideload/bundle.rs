// This file was made using https://github.com/Dadoum/Sideloader as a reference.
// I'm planning on redoing this later to better handle entitlements, extensions, etc, but it will do for now

use isideload_vfs::fs::File;
use plist::{Dictionary, Value, to_writer_binary};
use rootcause::prelude::*;
use std::{
    io::BufWriter,
    path::{Path, PathBuf},
};

use crate::SideloadError;

#[derive(Debug, Clone)]
pub struct Bundle {
    pub app_info: Dictionary,
    pub bundle_dir: PathBuf,

    app_extensions: Vec<Bundle>,
    frameworks: Vec<Bundle>,
    _libraries: Vec<String>,
}

impl Bundle {
    pub fn new(bundle_dir: PathBuf) -> Result<Self, Report> {
        let mut bundle_path = bundle_dir;
        // Remove trailing slash/backslash
        if let Some(path_str) = bundle_path.to_str()
            && (path_str.ends_with('/') || path_str.ends_with('\\'))
        {
            bundle_path = PathBuf::from(&path_str[..path_str.len() - 1]);
        }

        let info_plist_path = bundle_path.join("Info.plist");
        assert_bundle(
            isideload_vfs::fs::metadata(&info_plist_path).is_ok(),
            &format!("No Info.plist here: {}", info_plist_path.display()),
        )?;

        let plist_data = isideload_vfs::fs::read(&info_plist_path).context(
            SideloadError::InvalidBundle("Failed to read Info.plist".to_string()),
        )?;

        let app_info = plist::from_bytes(&plist_data).context(SideloadError::InvalidBundle(
            "Failed to parse Info.plist".to_string(),
        ))?;

        // ExtensionKit extensions (including Background Assets) live in Extensions.
        let mut app_extensions = Vec::new();
        for directory in ["PlugIns", "Extensions"] {
            let extensions_dir = bundle_path.join(directory);
            if !isideload_vfs::fs::metadata(&extensions_dir).is_ok() {
                continue;
            }
            let entries = isideload_vfs::fs::read_dir(&extensions_dir)
                .context(SideloadError::InvalidBundle(format!(
                    "Failed to read {} directory", directory
                )))?;
            for entry in entries {
                let entry = entry.context("Failed to read extension entry")?;
                if entry.file_type().map(|ft| ft.is_dir()).unwrap_or(false)
                    && isideload_vfs::fs::metadata(&entry.path().join("Info.plist")).is_ok()
                {
                    // A malformed nested bundle must fail preflight, not disappear.
                    app_extensions.push(Bundle::new(entry.path())?);
                }
            }
        }

        // Load frameworks from Frameworks directory
        let frameworks_dir = bundle_path.join("Frameworks");
        let frameworks = if isideload_vfs::fs::metadata(&frameworks_dir).is_ok() {
            isideload_vfs::fs::read_dir(&frameworks_dir)
                .context(SideloadError::InvalidBundle(
                    "Failed to read Frameworks directory".to_string(),
                ))?
                .filter_map(|entry| entry.ok())
                .filter(|entry| {
                    entry.file_type().map(|ft| ft.is_dir()).unwrap_or(false)
                        && isideload_vfs::fs::metadata(&entry.path().join("Info.plist")).is_ok()
                })
                .filter_map(|entry| Bundle::new(entry.path()).ok())
                .collect()
        } else {
            Vec::new()
        };

        // Find all .dylib files in the bundle directory (recursive)
        let libraries = find_dylibs(&bundle_path, &bundle_path)?;

        Ok(Bundle {
            app_info,
            bundle_dir: bundle_path,
            app_extensions,
            frameworks,
            _libraries: libraries,
        })
    }

    pub fn set_bundle_identifier(&mut self, id: &str) {
        let old_id = self.bundle_identifier().and_then(|s| Some(s.to_string()));
        if let Some(Value::Array(bg_tasks)) =
            self.app_info.get_mut("BGTaskSchedulerPermittedIdentifiers")
        {
            for task in bg_tasks.iter_mut() {
                if let Value::String(task_id) = task {
                    if let Some(old_bundle_id) = &old_id {
                        if task_id.contains(old_bundle_id) {
                            *task_id = task_id.replace(old_bundle_id, id);
                        }
                    }
                }
            }
        }

        self.app_info.insert(
            "CFBundleIdentifier".to_string(),
            Value::String(id.to_string()),
        );
    }

    pub fn bundle_identifier(&self) -> Option<&str> {
        self.app_info
            .get("CFBundleIdentifier")
            .and_then(|v| v.as_string())
    }

    pub fn bundle_name(&self) -> Option<&str> {
        self.app_info
            .get("CFBundleName")
            .and_then(|v| v.as_string())
    }

    pub fn app_extensions(&self) -> &[Bundle] {
        &self.app_extensions
    }

    pub fn app_extensions_mut(&mut self) -> &mut [Bundle] {
        &mut self.app_extensions
    }

    pub fn frameworks(&self) -> &[Bundle] {
        &self.frameworks
    }

    pub fn frameworks_mut(&mut self) -> &mut [Bundle] {
        &mut self.frameworks
    }

    pub fn write_info(&self) -> Result<(), Report> {
        let info_plist_path = self.bundle_dir.join("Info.plist");
        // plist::to_file_binary(&info_plist_path, &self.app_info).context(
        //     SideloadError::InvalidBundle("Failed to write Info.plist".to_string()),
        // )?;
        let mut file = File::create(&info_plist_path).context(SideloadError::InvalidBundle(
            "Failed to write Info.plist".to_string(),
        ))?;
        to_writer_binary(BufWriter::new(&mut file), &self.app_info).context(
            SideloadError::InvalidBundle("Failed to create Info.plist writer".to_string()),
        )?;

        file.sync_all().context(SideloadError::InvalidBundle(
            "Failed to sync Info.plist".to_string(),
        ))?;
        Ok(())
    }

    fn from_dylib_path(dylib_path: PathBuf) -> Self {
        Self {
            app_info: Dictionary::new(),
            bundle_dir: dylib_path,
            app_extensions: Vec::new(),
            frameworks: Vec::new(),
            _libraries: Vec::new(),
        }
    }

    fn collect_dylib_bundles(&self) -> Vec<Bundle> {
        self._libraries
            .iter()
            .map(|relative| Self::from_dylib_path(self.bundle_dir.join(relative)))
            .collect()
    }

    fn collect_nested_bundles_into(&self, bundles: &mut Vec<Bundle>) {
        for bundle in &self.app_extensions {
            bundles.push(bundle.clone());
            bundle.collect_nested_bundles_into(bundles);
        }

        for bundle in &self.frameworks {
            bundles.push(bundle.clone());
            bundle.collect_nested_bundles_into(bundles);
        }
    }

    pub fn collect_nested_bundles(&self) -> Vec<Bundle> {
        let mut bundles = Vec::new();
        self.collect_nested_bundles_into(&mut bundles);
        bundles.extend(self.collect_dylib_bundles());
        bundles
    }

    pub fn collect_bundles_sorted(&self) -> Vec<Bundle> {
        let mut bundles = self.collect_nested_bundles();
        bundles.push(self.clone());
        bundles.sort_by_key(|b| b.bundle_dir.components().count());
        bundles.reverse();
        bundles
    }
}

fn assert_bundle(condition: bool, msg: &str) -> Result<(), Report> {
    if !condition {
        bail!(SideloadError::InvalidBundle(msg.to_string()))
    } else {
        Ok(())
    }
}

fn find_dylibs(dir: &Path, bundle_root: &Path) -> Result<Vec<String>, Report> {
    let mut libraries = Vec::new();

    fn collect_dylibs(
        dir: &Path,
        bundle_root: &Path,
        libraries: &mut Vec<String>,
    ) -> Result<(), Report> {
        let entries = isideload_vfs::fs::read_dir(dir).context(SideloadError::InvalidBundle(
            format!("Failed to read directory {}", dir.display()),
        ))?;

        for entry in entries {
            let entry = entry.context(SideloadError::InvalidBundle(
                "Failed to read directory entry".to_string(),
            ))?;

            let path = entry.path();
            let file_type = isideload_vfs::fs::metadata(&path)
                .map(|m| m.file_type())
                .context(SideloadError::InvalidBundle(
                    "Failed to get file type".to_string(),
                ))?;

            if file_type.is_file() {
                if let Some(name) = path.file_name().and_then(|n| n.to_str())
                    && name.ends_with(".dylib")
                {
                    // Get relative path from bundle root
                    if let Ok(relative_path) = path.strip_prefix(bundle_root)
                        && let Some(relative_str) = relative_path.to_str()
                    {
                        libraries.push(relative_str.to_string());
                    }
                }
            } else if file_type.is_dir() {
                collect_dylibs(&path, bundle_root, libraries)?;
            }
        }
        Ok(())
    }

    collect_dylibs(dir, bundle_root, &mut libraries)?;
    Ok(libraries)
}


#[cfg(test)]
mod extensionkit_regression_tests {
    use super::*;
    use crate::sideload::application::Application;
    fn fixture() -> PathBuf {
        let root = std::env::temp_dir().join(format!("cyberport-bundle-fixture-{}-{}", std::process::id(),
            std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos()));
        for (rel, id) in [("", "org.example.host"), ("PlugIns/Widget.appex", "org.example.host.widget"),
                         ("Extensions/Downloader.appex", "org.example.host.downloader")] {
            let path=root.join(rel); std::fs::create_dir_all(&path).unwrap();
            let mut d=Dictionary::new();d.insert("CFBundleIdentifier".into(),Value::String(id.into()));
            plist::to_file_xml(path.join("Info.plist"),&Value::Dictionary(d)).unwrap();
        }
        root
    }
    #[test]
    fn extensionkit_discovers_both_extension_directories_and_rewrites_ids() {
        let root=fixture();let bundle=Bundle::new(root.clone()).unwrap();
        assert_eq!(bundle.app_extensions().len(),2);
        let mut app=Application{bundle};
        app.update_bundle_id("org.example.host","org.example.host.NEWTEAM").unwrap();
        let mut ids=app.bundle.app_extensions().iter().map(|b|b.bundle_identifier().unwrap().to_owned()).collect::<Vec<_>>();ids.sort();
        assert_eq!(ids,vec!["org.example.host.NEWTEAM.downloader","org.example.host.NEWTEAM.widget"]);
        std::fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn extensionkit_malformed_child_fails_instead_of_being_silently_omitted() {
        let root=fixture();std::fs::write(root.join("Extensions/Downloader.appex/Info.plist"),b"not a plist").unwrap();
        assert!(Bundle::new(root.clone()).is_err());std::fs::remove_dir_all(root).unwrap();
    }
}
