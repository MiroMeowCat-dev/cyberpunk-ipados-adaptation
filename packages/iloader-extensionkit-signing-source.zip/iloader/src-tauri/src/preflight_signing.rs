//! Local-only signing checkpoint. This module never transfers or installs an app.
use std::path::Path;
use isideload::{dev::devices::DevicesApi, util::device::IdeviceInfo};
use serde::Serialize;
use tauri::{State, Window};
use crate::{device::{DeviceInfoMutex, get_provider}, error::AppError,
    sideload::{SideloaderMutex, SideloaderGuard}};

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct SigningCheckpoint {
    schema: u32,
    signed_app_path: String,
    target_udid: String,
    installed: bool,
    preflight_passed: bool,
    checkpoint_path: String,
}

fn copy_bundle(source: &Path, target: &Path) -> Result<(), AppError> {
    // Fail on links instead of copying a tree which can escape its bundle.
    let meta = std::fs::symlink_metadata(source)
        .map_err(|e| AppError::Filesystem("Cannot inspect signed bundle".into(), e.to_string()))?;
    if meta.file_type().is_symlink() {
        return Err(AppError::Misc("Signed bundle contains an unsupported symbolic link".into()));
    }
    if meta.is_dir() {
        std::fs::create_dir(target).map_err(|e| AppError::Filesystem("Cannot create checkpoint".into(), e.to_string()))?;
        for entry in std::fs::read_dir(source).map_err(|e| AppError::Filesystem("Cannot read signed bundle".into(), e.to_string()))? {
            let entry = entry.map_err(|e| AppError::Misc(e.to_string()))?;
            copy_bundle(&entry.path(), &target.join(entry.file_name()))?;
        }
    } else if meta.is_file() {
        std::fs::copy(source, target).map_err(|e| AppError::Filesystem("Cannot save signed bundle".into(), e.to_string()))?;
    } else {
        return Err(AppError::Misc("Unsupported bundle file type".into()));
    }
    Ok(())
}

#[tauri::command]
pub async fn prepare_signing_checkpoint(
    _window: Window,
    device_state: State<'_, DeviceInfoMutex>,
    sideloader_state: State<'_, SideloaderMutex>,
    app_path: String,
) -> Result<SigningCheckpoint, AppError> {
    let selected = device_state.lock().unwrap().clone().ok_or(AppError::NoDeviceSelected)?;
    let provider = get_provider(&selected.info).await?;
    let actual = IdeviceInfo::from_device(&provider).await?;
    if actual.udid != selected.info.udid {
        return Err(AppError::Misc("Selected device no longer matches the connected device".into()));
    }
    let mut guard = SideloaderGuard::take(&sideloader_state)?;
    let signer = guard.get_mut();
    let team = signer.get_team().await?;
    signer.get_dev_session().ensure_device_registered(&team, &actual.name, &actual.udid, None).await?;
    let (signed, _) = signer.sign_app(
        app_path.into(), Some(team), true,
        None::<fn(f32) -> std::future::Ready<()>>,
        Some(&selected.pairing), Some(&actual.udid),
    ).await?;
    let exe = std::env::current_exe().map_err(|e| AppError::Misc(e.to_string()))?;
    let root = exe.parent().ok_or_else(|| AppError::Misc("Executable directory unavailable".into()))?
        .join("signing-checkpoints").join(uuid::Uuid::new_v4().to_string());
    std::fs::create_dir_all(&root).map_err(|e| AppError::Filesystem("Cannot create checkpoint directory".into(), e.to_string()))?;
    let saved = root.join("Signed.app");
    copy_bundle(&signed, &saved)?;
    let json_path = root.join("checkpoint.json");
    let result = SigningCheckpoint {
        schema: 1, signed_app_path: saved.to_string_lossy().into_owned(),
        target_udid: actual.udid, installed: false, preflight_passed: false,
        checkpoint_path: json_path.to_string_lossy().into_owned(),
    };
    std::fs::write(&json_path, serde_json::to_vec_pretty(&result).map_err(|e| AppError::Misc(e.to_string()))?)
        .map_err(|e| AppError::Filesystem("Cannot write private checkpoint".into(), e.to_string()))?;
    Ok(result)
}
