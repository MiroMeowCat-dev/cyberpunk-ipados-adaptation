"""Fetch the pinned public CA roots needed by the source build."""
import hashlib
from pathlib import Path
from urllib.request import urlopen

ROOTS = {'AppleIncRootCertificate.cer': ('https://www.apple.com/appleca/AppleIncRootCertificate.cer', 'b0b1730ecbc7ff4505142c49f1295e6eda6bcaed7e2c68c5be91b5a11001f024'), 'AppleWWDRCAG3.cer': ('https://www.apple.com/certificateauthority/AppleWWDRCAG3.cer', 'dcf21878c77f4198e4b4614f03d696d89c66c66008d4244e1b99161aac91601f')}
target = Path(__file__).resolve().parent / 'apple-codesign-quick/assets'
target.mkdir(parents=True, exist_ok=True)
for name, (url, expected) in ROOTS.items():
    with urlopen(url, timeout=30) as response:
        data = response.read()
    if hashlib.sha256(data).hexdigest() != expected:
        raise ValueError('Public CA root hash differs: ' + name)
    (target / name).write_bytes(data)
    print('Verified public root: ' + name)
