
use apple_codesign_quick::{sign_bundle,BundleSigningSettings};
use plist::{Dictionary,Value};
use std::path::Path;
fn copy_tree(src:&Path,dest:&Path) {
    std::fs::create_dir_all(dest).unwrap();
    for entry in std::fs::read_dir(src).unwrap(){let e=entry.unwrap();let p=e.path();let d=dest.join(e.file_name());
        if p.is_dir(){copy_tree(&p,&d)}else{std::fs::copy(p,d).unwrap();}}
}
#[test]
fn extensionkit_signs_real_nested_code_and_seals_its_resources() {
    let source=std::env::var("PORT_SIGNING_FIXTURE").expect("fixture path required");
    let out=std::path::PathBuf::from(std::env::var("PORT_SIGNING_OUTPUT").expect("output path required"))
        .join(format!("RustSignedHost-{}.app",std::process::id()));
    assert!(!out.exists());copy_tree(Path::new(&source),&out);
    let mut host=Dictionary::new();host.insert("org.localports.offline-test-role".into(),Value::String("host".into()));
    let mut settings=BundleSigningSettings::new("",host,None);
    let mut child=Dictionary::new();child.insert("org.localports.offline-test-role".into(),Value::String("extension".into()));
    settings.entitlements_by_bundle_id.insert("org.localports.extensionkitfixture.downloader".into(),child);
    sign_bundle(&out,&settings).unwrap();
    let resources=Value::from_file(out.join("_CodeSignature/CodeResources")).unwrap();
    let files=resources.as_dictionary().unwrap()["files2"].as_dictionary().unwrap();
    for relative in ["Extensions/Downloader.appex/Info.plist","Extensions/Downloader.appex/Downloader",
                     "Extensions/Downloader.appex/_CodeSignature/CodeResources"]{assert!(files.contains_key(relative),"{} is not sealed",relative);}
    println!("OFFLINE_SIGNED_FIXTURE={}",out.display());
}
